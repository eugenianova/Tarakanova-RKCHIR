"use strict";
function onDragStart(event) {
    event.dataTransfer.setData('plain', event.target.id);
}
function onDragOver(event) {
    event.preventDefault();
}

let allPrice = document.querySelector('.full_price').querySelector('b');

function onDrop(event) {
    const id = event.dataTransfer.getData('plain');
    const price = document.getElementById(id).nextElementSibling;
    allPrice.textContent = +allPrice.textContent + (+price.querySelector('b').textContent);
    const draggableElement = document.getElementById(id);
    const dropzone = event.target;
    dropzone.appendChild(draggableElement);
    price.remove();
    event.dataTransfer.clearData();
}


// Первое задание

const contents = document.getElementById('contents');

contents.onclick = function (event) {

    let target = event.target.closest('a');  // ссылка на объект, которому было отправлено событие

    if (contents.contains(target)) {
        let leave = confirm(`Точно хотите перейти по ссылке?`); // модальное окно 
        if (!leave) return false;
    }
};

// Второе задание

const photos = document.getElementById('photos');

photos.onclick = function (event) {
    let picture = event.target.closest('img');
    mainImg.src = picture.src;
}

// Третье задание

const who = document.getElementById('who');
 

who.onclick = function (event) {
    if (event.target.tagName != "LI") return;
        event.target.classList.toggle('selected');
        let selected = who.querySelectorAll('.selected');
        selected.forEach(element => {
            element.classList.remove('selected');
        });
        event.target.classList.add('selected');
}

// Четвертое задание 

let thumb = slider.querySelector('.thumb');

thumb.onmousedown = function (event) {
 

    let rightEdge = slider.offsetWidth - thumb.offsetWidth;
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);

    function onMouseMove(event) {
        let newLeft = event.clientX - slider.getBoundingClientRect().left;
        // курсор вышел из слайдера => оставить бегунок в его границах.
        if (newLeft < 0) {
            newLeft = 0;
        }
        if (newLeft > rightEdge) {
            newLeft = rightEdge;
        }
        thumb.style.left = newLeft + 'px';
    }

    function onMouseUp() {
        document.removeEventListener('mouseup', onMouseUp);
        document.removeEventListener('mousemove', onMouseMove);
    }

};

thumb.ondragstart = function () {
    return false;
};


// Шестое задание

const car = document.querySelector('#car');
const tree = document.querySelector('#tree')


car.onclick = function () {
    let start = Date.now();

    let timer = setInterval(function () {
        let timePassed = Date.now() - start;

        car.style.left = timePassed / 3 + 'px';

        if (timePassed > 3000) clearInterval(timer);

    }, 10);
}
tree.onclick = function () {
    let start = Date.now();
           tree.style.opacity = "100%";

    let timer = setInterval(function () {
 
        let timePassed = Date.now() - start;

        tree.style.opacity = 5000 / timePassed  + '%';

        if (timePassed > 5000) { clearInterval(timer); tree.style.opacity = "100%";};

    }, 10);
}


 